#include <iostream>
using namespace std;

int main() {
    double chiPhi;
    cin >> chiPhi;

    cout << chiPhi * 0.8 << endl;
    return 0;
}
