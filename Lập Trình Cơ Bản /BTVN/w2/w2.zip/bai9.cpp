#include <iostream>
using namespace std;

int main() {
    int soBanh;
    cin >> soBanh;

    cout << soBanh * 10 << " calories\n";
    return 0;
}
