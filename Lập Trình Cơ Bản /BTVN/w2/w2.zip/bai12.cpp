#include <iostream>
using namespace std;

int main() {
    double C;
    cin >> C;
    cout << C * 9/5 + 32 << endl;
    return 0;
}
