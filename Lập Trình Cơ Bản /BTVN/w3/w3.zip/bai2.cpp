#include <iostream>
using namespace std;

int main() {
    int n;
    cout << "Nhap so: ";
    cin >> n;
    
    string m;
    
    if (n == 1) {
        m = "I";
    }
    else if (n == 2) {
        m = "II";
    }
    else if (n == 3) {
        m = "III";
    }
    else if (n == 4) {
        m = "IV";
    }
    else if (n == 5) {
        m = "V";
    }
    else if (n == 6) {
        m = "VI";
    }
    else if (n == 7) {
        m = "VII";
    }
    else if (n == 8) {
        m = "VIII";
    }
    else if (n == 9) {
        m = "IX";
    }
    else if (n == 10) {
        m = "X";
    }
    else if (n == 11) {
        m = "XI";
    }
    else if (n == 12) {
        m = "XII";
    }
    else if (n == 13) {
        m = "XIII";
    }
    else if (n == 14) {
        m = "XIV";
    }
    else if (n == 15) {
        m = "XV";
    }
    else if (n == 16) {
        m = "XVI";
    }
    else if (n == 17) {
        m = "XVII";
    }
    else if (n == 18) {
        m = "XVIII";
    }
    else if (n == 19) {
        m = "XIX";
    }
    else if (n == 20) {
        m = "XX";
    }
    else {
        m = "Xin Hay Nhap Lai";
    }

    cout << n <<" Co so la ma la: " << m << endl;
    return 0;
}

