#include <iostream>
using namespace std;
int main() {
	int a,b;
	cout<<"A=";cin>>a;
	cout<<"B=";cin>>b;
	if (a<b){
	cout<<b<<" lon hon "<<a;
	}
	else{
		cout<<a<<" lon hon "<<b;
	}
	return 0;
}
