#include <iostream>
using namespace std;
int main() {

    cout << "Kích thước của kiểu char: " << sizeof(char) << " byte" << endl;
    cout << "Kích thước của kiểu int: " << sizeof(int) << " byte" << endl;
    cout << "Kích thước của kiểu float: " << sizeof(float) << " byte" << endl;
    cout << "Kích thước của kiểu double: " << sizeof(double) << " byte" << endl;
    return 0;
}