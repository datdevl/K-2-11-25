#include <iostream>
using namespace std;
int main(){
    float thueb=0.04;
    float thueq=0.02;
    int gh=95;
    float sthue=gh*(thueb+thueq);
    cout<<"Số thuế phải nộp cho giá hàng là: "<<sthue<<endl;
}