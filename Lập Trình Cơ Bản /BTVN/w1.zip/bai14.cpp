#include <iostream>
#include <string>
using namespace std;
int main() {
    string ten,dc,zip,sdt,cn;
    cout<<"Nhập tên của bạn ";
    cin>>ten;
    cout<<"Nhập địa chỉ của bạn ";
    cin>>dc;
    cout<<"Nhập zip của bạn ";
    cin>>zip;
    cout<<"Nhập số điện thoại của bạn ";
    cin>>sdt;
    cout<<"Nhập chuyên ngành của bạn ";
    cin>>cn;
    cout<<"________________"<<endl;
    cout<<"Tên: "<<ten<<endl;
    cout<<"Địa chỉ: "<<dc<<endl;
    cout<<"Zip: "<<zip<<endl;
    cout<<"Số điện thoại: "<<sdt<<endl;
    cout<<"Chuyên ngành: "<<cn<<endl;
    return 0;    
}