#include <iostream>
using namespace std;
int main(){
    // 20 gallon ~ 23.5 dặm; 28.9 dặm chô mỗi gallon trên cao tốc
    float n=23.5*20;
    float m=28.9*20;
    cout<<"Quảng đường ô tô đi được với một mình xăng khi di chuyener trên thị trấn là "<<n<<endl;
    cout<<"Quảng đường ô tô đi được với một mình xăng khi di chuyển trên cao tốc là "<<m<<endl;
    return 0;
}