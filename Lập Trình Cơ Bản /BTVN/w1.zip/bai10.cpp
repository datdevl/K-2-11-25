#include <iostream>
using namespace std;
int main() {
    int x=15;
    int dc=375;
    int dam=dc/x;
    cout<<"số dặm trên mỗi gallon mà xe có thể đi được là: "<<dam<<" dặm"<<endl;
}