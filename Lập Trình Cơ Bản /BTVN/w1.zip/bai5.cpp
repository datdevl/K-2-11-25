#include <iostream>
using namespace std;
int main(){
    int a=28;
    int b=32;
    int c=37;
    int d=24;
    int e=33;
    int tb=(a+b+c+d+e)/5;
    cout<<"Điểm trung bình của 5 môn là: "<<tb<<endl;
}