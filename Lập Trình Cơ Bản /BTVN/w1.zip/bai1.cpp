#include <iostream>
using namespace std;
int main(){
   int a=50;
   int b=100;
   int s;
   s=a+b;
   cout<<"Tổng của a và b là: "<<s<<endl;

}