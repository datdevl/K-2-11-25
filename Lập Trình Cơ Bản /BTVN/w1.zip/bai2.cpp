#include <iostream>
using namespace std;
int main() {
    float pt=0.58;
    float dt=8.6;
    float tien=pt*dt;
    cout<<"Với 58% tổng doanh thu thì với "<<dt<<" tỷ doanh thu thì số tiền nhận được là: "<<endl;
    cout<<"Tiền là: "<<tien<<" triệu $"<<endl;
}