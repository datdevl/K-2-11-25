#include <iostream>
using namespace std;
int main() {
    float s=43.560;
    cout<<"Số mẫu đất trên một khu đất có diện tích 391.876 feet vuông là: "<<391.876/s<<" mẫu"<<endl;
    return 0;
}