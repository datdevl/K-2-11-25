#include <iostream>
using namespace std;
int main(){
    float kiem=2.200;
    float annualPay=kiem*26;
    cout<<"Lương hàng năm của bạn là: "<<annualPay<<" $"<<endl;
}