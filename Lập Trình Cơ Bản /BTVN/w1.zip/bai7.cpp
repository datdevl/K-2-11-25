#include <iostream>
using namespace std;
int main() {
    float ht=1.5;
    cout<<"Số mm sẽ tăng lên so với mực nước biển hiện tại sau 5 năm là: "<<ht*5<<" mm"<<endl;
    cout<<"Số mm sẽ tăng lên so với mực nước biển hiện tại sau 7 năm là: "<<ht*7<<" mm"<<endl;
    cout<<"Số mm sẽ tăng lên so với mực nước biển hiện tại sau 10 năm là: "<<ht*10<<" mm"<<endl;
    return 0;
}