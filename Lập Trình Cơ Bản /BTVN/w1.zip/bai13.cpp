#include <iostream>
using namespace std;
int main() {
    float ln=0.35;
    float cp=14.95;
    float s=cp*(1+(ln)/100);
    cout<<"Giá bán của một bo mạch là: "<<s<<" $"<<endl;
    return 0;
}