#include <iostream>
using namespace std;
int main() {
    int n, m;
    cout<<"Nhập số sinh viên: ";
    cin>>n;
    cout<<"Nhập số môn học: ";
    cin>>m;
    float diem[10][10];
    for (int i = 0; i < n; i++) {
        cout<<"Nhập điểm sinh viên " << i + 1<<endl;
        for (int j = 0; j < m; j++) {
            cout<<"Môn " << j + 1 << ": ";
            cin>>diem[i][j];
        }
    }
    cout<<"Kết quả xếp loại";
    for (int i = 0; i < n; i++) {
        float tong = 0;
        for (int j = 0; j < m; j++)
            tong += diem[i][j];
        float dtb = tong/m;
        cout << "Sinh viên " << i + 1
             << " | Điểm TB = " << dtb
             << " | Xếp loại: ";
        if (dtb >= 9 && dtb <=10)
            cout << "Xuất sắc";
        else if (dtb >= 8 && dtb<9)
            cout << "Giỏi";
        else if (dtb >= 7 && dtb<8)
            cout << "Khá";
        else if (dtb >= 5 && dtb<7)
            cout << "Trung bình";
        else if (dtb >= 0 && dtb<5)
            cout << "Yếu";
        else
            cout<<" Nhập sai điểm"<<endl;
    }
    return 0;
}
