#include <iostream>
using namespace std;
int main() {
    int n,m;
    cout<< "Nhập số lượng sinh viên: ";
    cin>>n;
    cout<<"Nhập số môn học: ";
    cin>>m;
    cout<<"Số sinh viên: "<<n<< endl;
    cout<<"Số môn học: "<<m<< endl;
    return 0;
}
