#include <iostream>
using namespace std;
int main() {
    int n,m;
    cout<<"Nhập vào số sinh viên: ";
    cin>>n;
    cout<<"Nhập vào môn học: ";
    cin>>m;
    float diem[10][10];
    for (int i = 0; i < n; i++){
        cout << "Sinh vien " << i + 1 << endl;
        for (int j = 0; j < m; j++){
            cout<<"Môn " << j + 1 << ": ";
            cin >> diem[i][j];
            }
        }
    cout<<"Điểm trung bình:"<<endl;
    for (int i = 0; i < n; i++) {
        float tong = 0;
        for (int j = 0; j < m; j++)
            tong += diem[i][j];
        cout<<"Sinh viên " << i + 1 << " là: "<<tong/m<< endl;
    }
    return 0;
}
