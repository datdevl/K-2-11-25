#include <iostream>
using namespace std;
int main() {
    int n,m;
    cout<<"Nhập số sinh viên: ";
    cin >>n;
    cout<<"Nhập số môn học: ";
    cin>>m;
    float diem[10][10];
    for (int i = 0; i < n; i++) {
        cout<<"Sinh viên "<<i+1<< endl;
        for (int j = 0; j < m; j++) {
            cout<<"Môn "<<j + 1<< ": ";
            cin>>diem[i][j];
        }
    }
    cout<<"Danh sách điểm:"<<endl;
    for (int i = 0; i < n; i++) {
        cout<<"Sinh Viên "<<i + 1<<": ";
        for (int j = 0; j < m; j++) {
            cout<<diem[i][j] << " ";
        }
        cout<<endl;
    }
    return 0;
}
