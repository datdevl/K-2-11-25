#include <iostream>
#include <cmath>
using namespace std;

int main(){
    double a, b, c;
    cin >> a >> b >> c;

    if (a == 0) {
        cout << "sai";
        return 0;
    }

    double delta = b*b - 4*a*c;

    if (delta < 0){
        cout << "vonghiem";
    }
    else if(delta == 0){
        double x = -b / (2*a);
        if (abs(x) < 1e-9) x = 0; 
        cout << x;
    }
    else{
        double x1 = (-b + sqrt(delta)) / (2*a);
        double x2 = (-b - sqrt(delta)) / (2*a);

        if (abs(x1) < 1e-9) x1 = 0;
        if (abs(x2) < 1e-9) x2 = 0;

        cout << x1 << endl;
        cout << x2;
    }
}