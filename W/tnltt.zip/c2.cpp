//Tong SCP
#include <iostream>
#include <cmath>
using namespace std;
bool scp(int n){
    if (n<0) return false;
    int m=(sqrt)(n);
    if (m*m==n) return true;
    return false;
}
int main(){
    int n;
    cin>>n;
    int a[n];
    for (int i=0;i<n;i++){
        cin>>a[i];
    }
    int tong=0;
    for (int i=0;i<n;i++){
        if (scp(a[i]) == true ){
            tong=tong+a[i];
        }
    }
    cout<<tong;
}