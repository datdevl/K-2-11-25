#include <iostream>
using namespace std;
int main(){
    int a[100];
    int n,max,min;
    cin>>n;
    for (int i=0;i<n;i++){
        cin>>a[i];
        if (i==0){
            max = a[i];
            min = a[i];
        }
        else{
            if (max<a[i]){
                max=a[i];
            }
            else if(min>a[i]){
                min=a[i];
            }
        }
    }
    cout<<min<<endl<<max;
}