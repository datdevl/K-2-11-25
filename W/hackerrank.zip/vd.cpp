#include <iostream>
using namespace std;

int main(){
    int n, k;
    int a[100];

    cin >> n;
    for (int i = 0; i < n; i++){
        cin >> a[i];
    }

    cin >> k;   // vị trí cần xóa (0-based)

    // Xóa phần tử thứ k
    for (int i = k; i < n - 1; i++){
        a[i] = a[i + 1];
    }
    n--;

    // In mảng sau khi xóa
    for (int i = 0; i < n; i++){
        cout << a[i] << " ";
    }

    return 0;
}
