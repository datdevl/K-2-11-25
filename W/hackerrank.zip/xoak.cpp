#include <iostream>
using namespace std;
int main(){
    int n,k;
    int a[100];
    cin>>n;
    for (int i=0;i<n;i++){
        cin>>a[i];
    }
    cin>>k;
    for (int i=k;i<n;i++){
        a[i]=a[i+1];
    }
    n=n-1;
    for (int i=0;i<n;i++){
        cout<<a[i]<<" ";
    }
}
#dangsai