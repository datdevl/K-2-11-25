#include <iostream>
#include <cmath>
using namespace std;
int main(){
    int a,b,c;
    double x1,x2;
    cin>>a>>b>>c;
    double d=b*b-4*a*c;
    if (d>0){
        x1=(float)(-b+sqrt(d))/(2*a);
        x2=(float)(-b-sqrt(d))/(2*a);
        cout<<x1<<endl<<x2;
    }
    else if (d==0){
        x1=(-b/(2*a));
        cout<<x1;
    }
    else{
        cout<<"vonghiem";
    }
}Q