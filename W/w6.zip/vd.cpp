#include <iostream>
using namespace std;
int main(){
    int a[5];
    cout<<"Mời nhập phần tử thứ 1: ";cin>>a[0];
    cout<<"Mời nhập phần tử thứ 2: ";cin>>a[1];
    cout<<"Mời nhập phần tử thứ 3: ";cin>>a[2];
    cout<<"Mời nhập phần tử thứ 4: ";cin>>a[3];
    cout<<"Mời nhập phần tử thứ 5: ";cin>>a[4];
    cout<<endl<<"------------------"<<endl;
    cout<<"Giá trị phần tử bạn đã nhập: ";
    cout<<endl<<"------------------"<<endl;
    for (int i=1;i<=5;i++){
        cout<<"Giá trị của phần tử thứ "<<i<<" là: "<<a[i-1]<<endl;
    }
}