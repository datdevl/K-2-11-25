// ghi mảng a[5] vào tệp mangso.txt
#include <iostream>
#include <fstream>
using namespace std;
int main(){
	ofstream fileghi;	//mở để ghi
	fileghi.open("mangso.txt");
	int a[5];
	for (int i = 0; i < 5; i++){
		cout << "nhap du lieu cho phan tu thu " << i+1<< endl;
		cin >> a[i];
	}
	for (int i = 0; i < 5 ; i++){
		cout << a[i] << "\t";
	}
	for(int i = 0; i < 5; i++)
	{
		fileghi << a[i] << "\t";
	}
	fileghi.close();
	return 0;
}