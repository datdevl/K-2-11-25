#include <iostream>
using namespace std;
int main(){
    int a[5];
    cout<<"Mời nhập phần tử thứ 1: ";cin>>a[0];
    cout<<"Mời nhập phần tử thứ 2: ";cin>>a[1];
    cout<<"Mời nhập phần tử thứ 3: ";cin>>a[2];
    cout<<"Mời nhập phần tử thứ 4: ";cin>>a[3];
    cout<<"Mời nhập phần tử thứ 5: ";cin>>a[4];
    cout<<endl<<"------------------"<<endl;
    int i=0;
    do{
        cout<<"Giá trị của phần tử thứ "<<i<<" là: "<<a[i]<<endl;
        i++;
    }
    while (i<5);
    return 0;
}