#include <iostream>
#include <fstream>
using namespace std;
int main(){
    ifstream file;
    file.open("mangso.txt");
    int a[5];
    int dem=0;
    while (file.eof()!=true){
        file>>a[dem];
        dem=dem+1;
    }
    file.close();
    for (int i=0;i<5;i++){
        cout<<a[i]<<"\t";
    }
}