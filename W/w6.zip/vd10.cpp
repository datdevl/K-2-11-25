#include <iostream>
using namespace std;

// hàm nguyên mẫu
void nhapmang(int a[10][10], int n);
void inra(int a[10][10], int n);

int main(){
    int a[10][10];
    int n = 3;
    nhapmang(a, n);
    inra(a, n);
    return 0;
}

void nhapmang(int a[10][10], int n){
    for (int i = 0; i < n; i++){
        for (int j = 0; j < n; j++){
            cout << "Nhap a[" << i+1 << "][" << j+1 << "]: ";
            cin >> a[i][j];
        }
    }
}

void inra(int a[10][10], int n){
    cout << "\nMa tran vua nhap:\n";
    for (int i = 0; i < n; i++){
        for (int j = 0; j < n; j++){
            cout << a[i][j] << "\t";
        }
        cout << endl;
    }
}
