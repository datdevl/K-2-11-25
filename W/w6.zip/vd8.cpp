#include <iostream>
using namespace std;
int main(){
    int a[10][10];
    for (int i=0;i<3;i++){
        for (int j=0;j<4;j++){
            cout<<"Mời nhập phần tử: "<<i+1<<"|"<<j+1<<endl;
            cin>>a[i][j];
        }
    }
    for (int i=0;i<3;i++){
        for (int j =0;j<4;j++){
            cout<<a[i][j]<<"\t";
        }
        cout<<endl;
    }
}