#include <iostream>
#include <fstream>
using namespace std;
int main(){
    ofstream file;
    file.open("mangso.txt");
    int a[5];
    for (int i;i<5;i++){
        cout<<"Nhập giá trị: ";cin>>a[i];
        file <<a[i]<<"\t";
    }
    file.close();
}