#include <iostream>
using namespace std;
int main(){
    int a[100];
    for (int i;i<10;i++){
        cout<<"Nhập phần tử: ";cin>>a[i];
    }
    for (int i;i<10;i++){
        cout<<"giá trị là: "<<a[i]<<endl;
    }
}