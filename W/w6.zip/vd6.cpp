#include <iostream>
#include <fstream>
using namespace std;
int main(){
    ifstream file;  //mở để đọc từ file
    file.open("mangso.txt");
    int a[5];
    file>>a[0];
    file>>a[1];
    file>>a[2];
    file>>a[3];
    file>>a[4];
    for (int i=0;i<5;i++){
        cout<<a[i]<<endl;
    }
    file.close();
}
