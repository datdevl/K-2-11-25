// viết hàm nhập vào mảng và in mảng ra màn hinh
#include <iostream>
using namespace std;
void nhapmang(int a[][10], int n);
void inmang(int a[][10],int n);
int main(){
	int a[10][10];
	cout << "nhap gia tri cho mang 2 chieu" << endl;
	nhapmang(a,3);
	cout << "in mang 2 chieu" << endl;
	inmang(a,3);
	return 0;
}
void nhapmang(int a[][10], int n){
	for (int i =0;i < n;i++){
		for (int j = 0; j < n;j++){
			cout << "nhap a [" << i+1<<","<<j+1<< "]" << endl;
			cin >> a[i][j];
		}
	}
}
void inmang(int a[][10], int n){
	for (int i =0; i<n; i++){
		for(int j =0; j < n; j++){
			cout << a[i][j] << "\t";
		}
		cout << endl;
	}
}