#include <iostream>
using namespace std;
int main(){
    int a[5];
    for (int i=0;i<5;i++){
        cout<<"Nhập giá trị phần tử thứ "<<i+1<<": ";
        cin>>a[i];
    }
    for (int i=0;i<5;i++){
        cout<<"Giá trị của phần tử thứ "<<i+1<<" là: "<<a[i]<<endl;
    }
}