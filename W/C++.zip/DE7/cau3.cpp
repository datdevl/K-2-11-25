#include <iostream>
#include <string>
using namespace std;
struct KhachHang{
    string TenKH;
    double SoTienMua;
};
int main(){
    int n;
    cout<<"SL KH: ";cin>>n;
    KhachHang kh[n];
    for (int i=0;i<n;i++){
        cout<<"Tên KH số "<<i+1<<": ";
        cin>>kh[i].TenKH;
        cout<<"Số Tiền Mua: ";
        cin>>kh[i].SoTienMua;
    }
    cout<<"==="<<endl;
    int max=kh[0].SoTienMua;
    int vt=0;
    for (int i=1;i<n;i++){
        if (max<kh[i].SoTienMua){
            max = kh[i].SoTienMua;
            vt=i;
        }
    }
    cout<<"KH mua hàng cao nhất: "<<kh[vt].TenKH;

    return 0;
}