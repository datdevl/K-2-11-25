#include <iostream>
using namespace std;
int main(){
    float e;
    cout<<"Nhập điểm IELTS: ";cin>>e;
    if (e<4.5){
        cout<<"Học khóa dự bị";
    }
    else if (e<=6.0){
        cout<<"Học khóa tăng cường";
    }
    else {
        cout<<"Vào chuyên ngành";
    }
    return 0;
}