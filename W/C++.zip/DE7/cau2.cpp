#include <iostream>
using namespace std;
int main(){
    for (int i=0;i<=40;i+=10){
        cout<<i<<" độ C = "<<i*1.8+32<<" độ F"<<endl;
    }
    return 0;
}