#include <iostream>
using namespace std;
int main(){
    int i=0;
    while (i<=40){
        cout<<i<<" độ C = "<<i*1.8+32<<" độ F"<<endl;
        i+=10;
    }
    return 0;
}