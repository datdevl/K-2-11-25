#include <iostream>
using namespace std;
int main(){
    int n;
    cout<<"Nhập số giờ làm việc trong tuần: ";cin>>n;
    if (n<40){
        cout<<"Không thưởng";
    }
    else if (n<50){
        cout<<"Thưởng 500.000 VNĐ";
    }
    else if (n>=50){
        cout<<"Thưởng 1.000.000 VNĐ";
    }
    return 0;
}