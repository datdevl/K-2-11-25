#include <iostream>
using namespace std;
struct DienThoai{
    string TenDT;
    double GiaTien;
};
void nhap(DienThoai *dt,int n){
    for (int i=0;i<n;i++){
        cout<<"Tên Điện thoại thứ "<<i+1<<": ";
        cin>>dt[i].TenDT;
        cout<<"Giá tiền Điện thoại thứ "<<i+1<<": ";
        cin>>dt[i].GiaTien;
    }
    cout<<"====="<<endl;
}
void tb(DienThoai *dt,int n){
    float tong=0;
    for (int j=0;j<n;j++){
        cout<<"Tên Điện thoại thứ "<<j+1<<" chính là: ";
        cout<<dt[j].TenDT<<endl;
        cout<<"Giá tiền Điện thoại thứ "<<j+1<<" chính là ";
        cout<<dt[j].GiaTien<<endl;
        tong=tong+dt[j].GiaTien;
    }
    float tb=tong/n;
    cout<<"Giá triền Trung bình các Điện Thoại: "<<tb<<endl;
}
int main(){
    int n;
    cout<<"Nhập số lượng Điện thoại: ";cin>>n;
    DienThoai *dt = new DienThoai[n];
    nhap(dt,n);
    tb(dt,n);
    delete[] dt;
    return 0;
}