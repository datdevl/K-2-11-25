#include <iostream>
#include <string>
using namespace std;

struct Dienthoai {
    string TenDT;
    double GiaTien;
};

int main() {
    int n;
    cout << "Nhập số lượng Điện thoại: ";
    cin >> n;

    Dienthoai dt[n]; // mảng n phần tử

    for (int i = 0; i < n; i++) {
        cout << "Tên Điện thoại thứ " << i+1 << ": ";
        cin >> dt[i].TenDT;
        cout << "Giá tiền Điện thoại thứ " << i+1 << ": ";
        cin >> dt[i].GiaTien;
    }

    cout << "=========" << endl;

    for (int i = 0; i < n; i++) {
        cout << "Tên Điện thoại thứ " << i+1 << " chính là: " << dt[i].TenDT << endl;
        cout << "Giá tiền Điện thoại thứ " << i+1 << " chính là: " << dt[i].GiaTien << endl;
    }

    return 0;
}