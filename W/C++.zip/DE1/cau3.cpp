#include <iostream>
#include <string>
using namespace std;
struct Dienthoai{
    string TenDT;
    double GiaTien;
};
int main(){
    int n;
    int tb=0;
    cout<<"Nhập số lượng Điện thoại: ";cin>>n;
    Dienthoai dt[n];
    for (int i=0;i<n;i++){
        cout<<"Tên Điện thoại thứ "<<i+1<<": ";
        cin>>dt[i].TenDT;
        cout<<"Giá tiền Điện thoại thứ "<<i+1<<": ";
        cin>>dt[i].GiaTien;
    }
    cout<<"========="<<endl;
    for (int j=0;j<n;j++){
        cout<<"Tên Điện thoại thứ "<<j+1<<" chính là: ";
        cout<<dt[j].TenDT<<endl;
        cout<<"Giá tiền Điện thoại thứ "<<j+1<<" chính là ";
        cout<<dt[j].GiaTien<<endl;
        tb=(tb+dt[j].GiaTien)/n;
    }
    cout<<"Giá tiền Trung bình các Điện Thoại: "<<tb<<endl;
    cout<<"===="<<endl;
    return 0;
}