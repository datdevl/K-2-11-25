#include <iostream>
using namespace std;
int main(){
    int i=5;
    while (i<=30 ){
        cout<<"Tổng số calo tiêu thụ sau "<<i<<" là: "<<i*15<<endl;
        i=i+5;
    }
    return 0;
}