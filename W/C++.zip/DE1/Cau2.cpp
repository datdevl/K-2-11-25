#include <iostream>
using namespace std;
int main(){
    for (int i=5;i<=30;i=i+5){
        cout<<"Tổng số calo tiêu thụ sau "<<i<<" là: "<<i*15<<endl;
    }
    return 0;
}