#include <iostream>
using namespace std;
int main(){
    float bmi,h,m;
    cout<<"Nhập cân nặng: ";cin>>m;
    cout<<"Nhập chiều cao: ";cin>>h;
    bmi=m/(h*h);
    if (bmi<18.5){
        cout<<bmi<<": Gầy";
    }
    else if (bmi<=24.9){
        cout<<bmi<<": Bình thường";
    }
    else if (bmi >=25){
        cout<<bmi<<": Thừa cân";
    }
}