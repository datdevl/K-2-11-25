#include <iostream>
#include <string>
using namespace std;
struct Laptop{
    string HangSX;
    double TrongLuong;
};
void nhap(Laptop lt[],int n){
    for (int i=0;i<n;i++){
        cout<<"Laptop "<<i+1<<" Hãng: ";
        cin>>lt[i].HangSX;
        cout<<"Trọng lượng: ";
        cin>>lt[i].TrongLuong;
    }
}
void xuat(Laptop lt[],int n){
    for (int i=0;i<n;i++){
        if (lt[i].TrongLuong<1.5){
            cout<<"Laptop nhẹ hơn 1.5kg: "<<lt[i].HangSX<<endl;
        }
        else{
            cout<<"Không có Laptop nhẹ hơn 1.5kg"<<endl;
        }
    }

}

int main(){
    int n;
    cout<<"SL LAPTOP: ";cin>>n;
    Laptop lt[n];
    nhap(lt,n);
    cout<<"==="<<endl;
    xuat(lt,n);

    return 0;
}