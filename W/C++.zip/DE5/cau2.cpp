#include <iostream>
using namespace std;
int main(){
    int tong;
    int tl=20;
    for (int i=1;i<=5;i++){
        tong=tong+tl;
        cout<<"Sau "<<i<<" năm số tiền tích lũy: "<<tong<<" triệu"<<endl;
    }
    return 0;
}