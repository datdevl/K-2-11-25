#include <iostream>
using namespace std;
int main(){
    int tl=0,i=1;
    int tk=10;
    while (i<=5){
        tl=tl+tk;
        cout<<"Sau "<<i<<" năm số tiền tích lũy: "<<tl<<" triệu"<<endl;
        i=i+1;
    }
}