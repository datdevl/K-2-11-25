#include <iostream>
using namespace std;
int main(){
    int i=20;
    int vk=1;
    while (i<=120){
        vk=vk*2;
        cout<<"Số lượng vi khuẩn tại mốc "<<i<<" phút: "<<vk<<endl;
        i+=20;
    }
    return 0;
}