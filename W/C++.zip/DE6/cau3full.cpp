#include <iostream>
#include <string>
using namespace std;
struct MonHoc{
    string TenMon;
    int SoTinChi;
};
void nhap(MonHoc *mh,int n){
for (int i=0;i<n;i++){
        cout<<"Tên Môn thứ "<<i+1<<": ";
        cin>>mh[i].TenMon;
        cout<<"Số Tín Chỉ: ";cin>>mh[i].SoTinChi;
    }
}
void xuat(MonHoc *mh,int n){
    int tong=0;
    for (int i=0;i<n;i++){
        tong=tong+mh[i].SoTinChi;
    }
    cout<<"Tổng số tín chỉ là: "<<tong;
}
int main(){
    int n;
    cout<<"Số môn học: ";cin>>n;
    MonHoc *mh = new MonHoc [n];
    nhap(mh,n);
    cout<<"==="<<endl;
    xuat(mh,n);
    return 0;
}