#include <iostream>
using namespace std;
int main(){
    int n;
    cout<<"Nhập số năm kinh nghiệm: ";cin>>n;
    if (n<2){
        cout<<"Bậc 1";
    }
    else if (n<=5){
        cout<<"Bậc 2";
    }
    else if (n>5){
        cout<<"Bậc 3";
    }
    return 0;
}