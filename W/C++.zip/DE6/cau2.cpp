#include <iostream>
using namespace std;
int main(){
    int vk=1;
    for (int i=20;i<=120;i+=20){
        vk=vk*2;
        cout<<"Số lượng vi khuẩn tại mốc "<<i<<" phút: "<<vk<<endl;

    }
    return 0;
}