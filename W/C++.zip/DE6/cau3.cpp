#include <iostream>
#include <string>
using namespace std;
struct MonHoc{
    string TenMon;
    int SoTinChi;
};

int main(){
    int n;
    cout<<"Số môn học: ";cin>>n;
    MonHoc mh[n];
    for (int i=0;i<n;i++){
        cout<<"Tên Môn thứ "<<i+1<<": ";
        cin>>mh[i].TenMon;
        cout<<"Số Tín Chỉ: ";cin>>mh[i].SoTinChi;
    }
    cout<<"==="<<endl;
    int tong=0;
    for (int i=0;i<n;i++){
        tong=tong+mh[i].SoTinChi;
    }
    cout<<"Tổng số tín chỉ là: "<<tong;

    return 0;
}