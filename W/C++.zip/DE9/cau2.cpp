#include <iostream>
using namespace std;
int main(){
    int m=80;
    cout<<"Sau 2 Phút đi được: "<<2*m<<"m"<<endl;
    for (int i=5;i<=20;i+=5){
        cout<<"Sau "<<i<<" Phút đi được: "<<i*m<<"m"<<endl;
    }
    return 0;
}