#include <iostream>
using namespace std;
int main(){
    int m=80;
    int t[]={2,5,10,15,20};
    for (int i=0;i<5;i++){
        cout<<"Sau "<<t[i]<<" Phút đi được: "<<t[i]*m<<endl;
    }
    return 0;
}