#include <iostream>
#include <string>
using namespace std;
struct CaSi{
    string NgheDanh;
    int SoAlbum;
};

int main(){
    int n;
    cout<<"SL CaSi: ";cin>>n;
    CaSi cs[n];
    for (int i=0;i<n;i++){
        cout<<"Nghệ Danh CaSi thứ "<<i+1<<": ";
        cin>>cs[i].NgheDanh;
        cout<<"Số Album: ";
        cin>>cs[i].SoAlbum;
    }
    cout<<"==="<<endl;
    for (int i=0;i<n;i++){
        if (cs[i].SoAlbum>5){
            cout<<"CaSi trên 5 album: "<<cs[i].NgheDanh<<endl;
        }
    }
    return 0;
}