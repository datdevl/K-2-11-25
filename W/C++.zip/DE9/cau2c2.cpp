#include <iostream>
using namespace std;
int main(){
    int m=80;
    int i=5;
    cout<<"Sau 2 Phút đi được: "<<2*m<<"m"<<endl;
    while (i<=20){
        cout<<"Sau "<<i<<" Phút đi được: "<<i*m<<"m"<<endl;
        i+=5;
    }
    return 0;
}