#include <iostream>
using namespace std;
int main(){
    int n;
    cout<<"nhập tốc độ internet(Mbps):";cin>>n;
    if (n<30){
        cout<<"Chậm";
    }
    else if (n<=100){
        cout<<"trung bình";
    }
    else {
        cout<<"Nhanh";
    }
    return n;
}