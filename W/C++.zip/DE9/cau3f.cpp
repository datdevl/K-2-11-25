#include <iostream>
#include <string>
using namespace std;
struct CaSi{
    string NgheDanh;
    int SoAlbum;
};
void nhap(CaSi cs[],int n){
    for (int i=0;i<n;i++){
        cout<<"Nghệ Danh CaSi thứ "<<i+1<<": ";
        cin>>cs[i].NgheDanh;
        cout<<"Số Album: ";
        cin>>cs[i].SoAlbum;
    }

}
void xuat(CaSi cs[],int n){
    for (int i=0;i<n;i++){
        if (cs[i].SoAlbum>5){
            cout<<"CaSi trên 5 album: "<<cs[i].NgheDanh<<endl;
        }
    }

}
int main(){
    int n;
    cout<<"SL CaSi: ";cin>>n;
    CaSi cs[n];
    nhap(cs,n);
    cout<<"==="<<endl;
    xuat(cs,n);
    return 0;
}

