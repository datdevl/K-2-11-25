#include <iostream>
#include <string>
using namespace std;
struct DuAn{
    string TenDA;
    double KinhPhi;
};
int main(){
    int n;
    cout<<"SL dự án: ";cin>>n;
    DuAn da[n];
    for (int i=0;i<n;i++){
        cout<<"Tên dự án số "<<i+1<<" : ";
        cin>>da[i].TenDA;
        cout<<"Kinh phí DA số "<<1+1<<" :";
        cin>>da[i].KinhPhi;
    }
    cout<<"==="<<endl;
    int tong=0;
    for (int i=0;i<n;i++){
        tong=tong+da[i].KinhPhi;
    }
    cout<<"Tổng kinh phí ALL DA: "<<tong;
    return 0;
}