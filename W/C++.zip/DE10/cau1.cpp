#include <iostream>
using namespace std;
int main(){
    int n;
    cout<<"Số Debug: ";cin>>n;
    if (n==0){
        cout<<"Hoàn hảo";
    }
    else if(n<=5){
        cout<<"Chấp nhận được";
    }
    else{
        cout<<"Cần kiểm tra lại";
    }
    return 0;
}