#include <iostream>
using namespace std;
int main() {
    float t, ds;
    cout << "Nhập số tiền gửi tiết kiệm: ";
    cin >> t;
    ds = t; 
    cout << "Bảng số dư trong 6 tháng đầu tiên:" << endl;
    for (int i = 1; i <= 6; i++) {
        ds = ds * 1.015;   
        cout << "Tháng " << i << ": " << ds << endl;
    }
    cout << "Tổng số tiền sau 6 tháng là: " << ds << endl;
    return 0;
}