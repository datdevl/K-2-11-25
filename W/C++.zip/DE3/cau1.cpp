#include <iostream>
using namespace std;
int main(){
    int n,hh=0;
cout<<"Nhập doanh thu bán hàng(Triệu): ";cin>>n;
    if (n<100){
        hh+=2;
    }
    else if (n<300){
        hh+=5;
    }
    else if (n>=300){
        hh+=10;
    }
    cout<<"Tỷ lệ hoa hồng là: "<<hh<<"%";
}