#include <iostream>
#include <iostream>
using namespace std;
struct XeMay{
    string TenXe;
    int DungTich;
};

int main(){
    int n;
    cout<<"Nhập SL xe máy: ";cin>>n;
    XeMay xm[n];
    for (int i=0;i<n;i++){
        cout<<"Xe "<<i+1<<": ";
        cin.ignore();
        getline(cin,xm[i].TenXe);
        cout<<"Dung Tích: ";
        cin>>xm[i].DungTich;
    }
    cout<<"===LIST XE==="<<endl;
    for (int i=0;i<n;i++){
        cout<<"Xe "<<i+1<<": ";
        cout<<xm[i].TenXe<<endl;
        cout<<"Dung Tích: ";
        cout<<xm[i].DungTich<<endl;
    }
    int max=xm[0].DungTich;
    int vt=0;
    for (int i=1;i<n;i++){
                if (max<xm[i].DungTich){
            max = xm[i].DungTich;
            vt=i;
        }
    }
    
    cout<<"======"<<endl;
    cout<<"XE Max Là xe : "<<xm[vt].TenXe;
    return 0;
}