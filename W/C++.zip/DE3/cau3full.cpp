#include <iostream>
#include <string>
using namespace std;
struct XeMay{
    string TenXe;
    int DungTich;
};

void nhap(XeMay *xm,int n){
    cin.ignore();
    for (int i=0;i<n;i++){
        cout<<"Xe "<<i+1<<": ";
        getline(cin,xm[i].TenXe);
        cout<<"Dung Tích: ";
        cin>>xm[i].DungTich;
        cin.ignore();
    }
}
void xuat(XeMay *xm,int n){
    for (int i=0;i<n;i++){
        cout<<"Xe "<<i+1<<": ";
        cout<<xm[i].TenXe<<endl;
        cout<<"Dung Tích: ";
        cout<<xm[i].DungTich<<endl;
    }
}
void max(XeMay xm[],int n,int &vt){ //&vt là truyền ở main tham số vào
    int max=xm[0].DungTich;
    vt=0;
    for (int i=1;i<n;i++){
                if (max<xm[i].DungTich){
            max = xm[i].DungTich;
            vt=i;
        }
    }
}
int main(){
    int n;
    int vt;
    cout<<"Nhập SL xe máy: ";cin>>n;
    XeMay *xm = new XeMay [n];
    nhap(xm,n);
    cout<<"===LIST XE==="<<endl;
    xuat(xm,n);
    cout<<"===MAX XE==="<<endl;
    max(xm,n,vt);
    cout<<"XE Max Là xe : "<<xm[vt].TenXe;
    delete [] xm;
    return 0;

}