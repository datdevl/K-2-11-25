#include <iostream>
#include <string>
using namespace std;
struct HocSinh{
    string HoTen;
    double DiemTB;
};

int main(){
    int n;
    cout<<"Nhập số lượng học sinh:";cin>>n;
    HocSinh hs[n];
    int dem=0;
    for (int i=0;i<n;i++){
        cout<<"Tên HS số "<<i+1<<": ";
        cin>>hs[i].HoTen;
        cout<<"Điểm TB HS số "<<i+1<<": ";
        cin>>hs[i].DiemTB;
    }
    cout<<"===DANH SACH HS==="<<endl;
    for (int i=0;i<n;i++){
        cout<<"HS số "<<i+1<<": "<<hs[i].HoTen<<endl;
        cout<<"DiemTB HS số "<<i+1<<": "<<hs[i].DiemTB<<endl;
        if (hs[i].DiemTB>=8){
            dem=dem+1;
        }
    }
    cout<<"Số HS lớn hơn 8đ: "<<dem;

    return 0;
}