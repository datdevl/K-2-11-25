#include <iostream>
using namespace std;
int main(){
    int n;
    cout<<"Nhập nồng độ cồn: ";cin>>n;
    if (n<50){
        cout<<"Phạt 2 triệu";
    }
    else if (n<=80){
        cout<<"Phạt 5 triệu";
    }
    else if (n>80){
        cout<<"Phạt 10 triệu";

    }
    return 0;
}