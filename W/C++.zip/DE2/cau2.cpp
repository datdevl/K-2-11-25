#include <iostream>
using namespace std;
int main(){
    int i;
    for (i=1;i<=10;i++){
        cout<<"9 x "<<i<<" = "<<9*i<<endl;
    }
}