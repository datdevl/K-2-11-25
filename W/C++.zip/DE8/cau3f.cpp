#include <iostream>
#include <string>
using namespace std;
struct ThanhPho{
    string TenTP;
    long DanSo;
};
void nhap(ThanhPho tp[],int n){
    for (int i=0;i<n;i++){
    cout<<"Tên TP thứ "<<i+1<<": ";
    cin>>tp[i].TenTP;
    cout<<"Có Dân Số: ";
    cin>>tp[i].DanSo;
    }
}
void xuat(ThanhPho tp[],int n){
    long tb=0;
    for (int i=0;i<n;i++){
        tb=tb+tp[i].DanSo;
    }
    cout<<"Dân Số TB các TP: "<<tb;
    
}

int main(){
    int n;
    cout<<"Nhập số Thành Phố: ";cin>>n;
    ThanhPho tp[n];
    nhap(tp,n);
    cout<<"==="<<endl;
    xuat(tp,n);
    return 0;
}