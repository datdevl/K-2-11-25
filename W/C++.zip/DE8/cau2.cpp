#include <iostream>
using namespace std;
int main(){
    for(int i=1;i<=6;i++){
        int gt=1;
        for (int j=1;j<=i;j++){
            gt=gt*j;
        }
        cout<<i<<"! = "<<gt<<endl;
    }
    return 0;
}