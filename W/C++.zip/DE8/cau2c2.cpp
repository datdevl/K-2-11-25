#include <iostream>
using namespace std;
int main(){
    int i=1;
    int gt=1;
    while(i<=6){
        gt=gt*i;
        cout<<i<<"! = "<<gt<<endl;
        i++;
    }

}