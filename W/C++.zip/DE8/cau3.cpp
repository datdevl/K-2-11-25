#include <iostream>
#include <string>
using namespace std;
struct ThanhPho{
    string TenTP;
    long DanSo;
};
 int main(){
    int n;
    cout<<"Nhập số Thành Phố: ";cin>>n;
    ThanhPho tp[n];
    for (int i=0;i<n;i++){
        cout<<"Tên TP thứ "<<i+1<<": ";
        cin>>tp[i].TenTP;
        cout<<"Có Dân Số: ";
        cin>>tp[i].DanSo;
    }
    cout<<"==="<<endl;
    int tb=0;
    for (int i=0;i<n;i++){
        tb=tb+tp[i].DanSo;
    }
    cout<<"Dân Số TB các TP: "<<tb;
    return 0;
 }