#include <iostream>
using namespace std;
int main(){
    int n;
    cout<<"nhập số trang sách: ";cin>>n;
    if (n<100){
        cout<<"Sách mỏng";
    }
    else if(n<=300){
        cout<<"Sách trung bình";
    }
    else{
        cout<<"Sách dày";
    }
    return 0;
}