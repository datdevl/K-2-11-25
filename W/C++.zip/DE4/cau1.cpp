#include <iostream>
using namespace std;
int main(){
    int n;
    float dg;
    cout<<"Nhập chỉ số tiêu thụ điện (kWh):";
    cin>>n;
    if (n<50){
        dg=1678;
    }
    else if(n<=100){
        dg=1734;
    }
    else if(n>100){
        dg=2014;
    }
    cout<<"Đơn giá: "<<dg<<"VNĐ"<<endl;
    cout<<"Tiền điện: "<<(long long)dg*n<<" VNĐ";
    return 0;
}