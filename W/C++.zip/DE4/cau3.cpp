#include <iostream>
#include <string>
using namespace std;
struct NhanVien
{
    string MaNV;
    int LuongCB;
};

int main(){
    int n;
    cout<<"SL NV: ";cin>>n;
    NhanVien nv[n];
    for (int i=0;i<n;i++){
        cout<<"Mã NV "<<i+1<<": ";
        cin>>nv[i].MaNV;
        cout<<"Lương CB: ";
        cin>>nv[i].LuongCB;
    }
    cout<<"===="<<endl;
    int tong=0;
    for (int i=0;i<n;i++){
        tong=tong+nv[i].LuongCB;
    }
    cout<<"Tổng lương ALL NV: "<<tong;
    return 0;
}