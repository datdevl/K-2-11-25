#include <iostream>
#include <string>
using namespace std;
struct NhanVien{
    string MaNV;
    int LuongCB;
};
void nhap(NhanVien nv[],int n){
    for (int i=0;i<n;i++){
        cout<<"Mã NV "<<i+1<<": ";
        cin>>nv[i].MaNV;
        cout<<"Lương CB: ";
        cin>>nv[i].LuongCB;
    }
}
void xuat(NhanVien nv[], int n){
    int tong=0;
    for (int i=0;i<n;i++){
        tong=tong+nv[i].LuongCB;
    }
    cout<<"Tổng lương ALL NV: "<<tong;
}
int main(){
    int n;
    cout<<"SL NV: ";cin>>n;
    NhanVien nv[n];
    nhap(nv,n);
    cout<<"==="<<endl;
    xuat(nv,n);
    return 0;
}