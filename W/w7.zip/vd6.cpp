#include <iostream>
#include <string>
#include <fstream>
using namespace std;
// kiểu dữ liệu có cấu trúc struct
struct ngiu {
    string ten;
    string mautoc;
    int tuoi;
    string tinhcach;
    float chieucao; // Đổi thành float để tính toán chính xác
    float cannang;  // Đổi thành float
};

int main() {
    ofstream fi;
    fi.open("vd6.txt");
    ngiu ny;
    cout << "Nhập tên người yêu cũ: "; cin >> ny.ten;
    cout << "Nhập màu tóc: "; cin >> ny.mautoc;
    cout << "Nhập tuổi: "; cin >> ny.tuoi;
    cout << "Nhập tính cách: "; cin >> ny.tinhcach;
    cout << "Nhập chiều cao (m) (VD: 1.65): "; cin >> ny.chieucao;
    cout << "Nhập cân nặng (kg): "; cin >> ny.cannang;cout<<endl;

    cout << "==== ĐÃ GHI FILE NGIU CŨ CỦA BẠN ====" << endl;
    fi << "Tên: " << ny.ten << endl;
    fi << "Tuổi: " << ny.tuoi << endl;
    
    float bmi = ny.cannang / (ny.chieucao * ny.chieucao);
    fi << "Chỉ số BMI: " << bmi << endl;
    fi << "Xếp hạng: ==> ";
    if (bmi < 18.5) {
        fi << "THIẾU CÂN" << endl;
    } 
    else if (bmi >= 18.5 && bmi <= 24.9) {
        fi << "BÌNH THƯỜNG" << endl;
    } 
    else {
        fi << "THỪA CÂN" << endl;
    }

    return 0;
    fi.close();
}
