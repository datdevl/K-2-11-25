// viết hàm trên thành 3 hàm
// nhap mảng
// in mảng
// sắp xếp mang
#include <iostream>
using namespace std;
void nhapmang(int a[], int n);
void inmang(int a[], int n);
void sapxepsuibot(int a[], int n);
int main(){
	int a[10];
	int n;
	cout << "moi nhap n: " << endl;
	nhapmang(a,n);
	inmang(a,n);
	sapxepsuibot(a,n);
	inmang(a,n);
	return 0;
}