#include <iostream>
#include <string>
using namespace std;

struct ngiu {
    string ten;
    string mautoc;
    int tuoi;
    string tinhcach;
    float chieucao; // Đổi thành float để tính toán chính xác
    float cannang;  // Đổi thành float
};

int main() {
    ngiu ny;
    cout << "Nhập tên người yêu cũ: "; cin >> ny.ten;
    cout << "Nhập màu tóc: "; cin >> ny.mautoc;
    cout << "Nhập tuổi: "; cin >> ny.tuoi;
    cout << "Nhập tính cách: "; cin >> ny.tinhcach;
    cout << "Nhập chiều cao (m) (VD: 1.65): "; cin >> ny.chieucao;
    cout << "Nhập cân nặng (kg): "; cin >> ny.cannang;

    cout << "\n==== SAU ĐÂY LÀ NGIU CŨ CỦA BẠN ====" << endl;
    cout << "Tên: " << ny.ten << endl;
    cout << "Tuổi: " << ny.tuoi << endl;
    
    float bmi = ny.cannang / (ny.chieucao * ny.chieucao);
    cout << "Chỉ số BMI: " << bmi << endl;
    cout << "Xếp hạng: ==> ";

    // Cấu trúc if - else if - else chuẩn
    if (bmi < 18.5) {
        cout << "THIẾU CÂN" << endl;
    } 
    else if (bmi >= 18.5 && bmi <= 24.9) {
        cout << "BÌNH THƯỜNG" << endl;
    } 
    else {
        cout << "THỪA CÂN" << endl;
    }

    return 0;
}
