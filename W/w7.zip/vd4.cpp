//kiểu dữ liệu có cấu trúc
#include <iostream>
#include <string>
using namespace std;
struct sinhvien{
        string msv;
        string tensv;
        int diemltcb;
        int giaitich;
        
    };
int main(){
    sinhvien sv;
    cout<<"Hãy nhập tên sinh viên: ";cin>>sv.tensv;
    cout<<"Hãy nhập mã sinh viên: ";cin>>sv.msv;
    cout<<"Hãy nhập điểm lập trình cơ bản: ";cin>>sv.diemltcb;
    cout<<"Hãy nhập điểm giải tích: ";cin>>sv.giaitich;
    cout<<"----------------"<<endl;
    cout<<"tên sinh viên: ";cout<<sv.tensv<<endl;
    cout<<"mã sinh viên: ";cout<<sv.msv<<endl;
    cout<<"Hđiểm lập trình cơ bản: ";cout<<sv.diemltcb<<endl;
    cout<<"điểm giải tích: ";cout<<sv.giaitich<<endl;
    
}