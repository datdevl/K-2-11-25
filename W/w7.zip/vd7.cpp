// kiểu dữ liệu có cấu trúc
#include <iostream>
#include <string>
#include <fstream>
using namespace std;
	struct sinhvien{
		string masv;
		string tensv;
		int diemltcb;
		int giaitich;
	};
int main(){
	sinhvien sv[100];
	ifstream docfile;
	docfile.open("cntt1908.txt");
	do{
		int i =0;
		cout << "sinh vien thu " << i+1 << endl;
		cout << "ten sinh vien" << endl;
		docfile >> sv[i].tensv;
		cout << sv[i].tensv << endl; 
		cout << "Nhap masv" << endl;
		docfile >> sv[i].masv;
		cout << sv[i].masv<< endl;
		cout << "nhap diem lap trinh co ban" << endl;
		docfile >> sv[i].diemltcb;
		cout << sv[i].diemltcb<< endl;
		cout << "nhap diem giai tich" << endl;
		docfile >> sv[i].giaitich;	
		cout << sv[i].giaitich<< endl;
		i++;
	}while(docfile.eof()!=true);
	docfile.close();
	return 0;
}