//tạo hàm bài toán sắp xếp tuần tự
//gồm 4 hàm: hàm nhập mảng, hàm in mảng, hàm sắp xếp nổi bọt ( tuần tự)
#include <iostream>
using namespace std;
// hàm nhập mảng
void nhapmang(int a[], int &n) {
    cout << "Nhap so phan tu cua mang: ";
    cin >> n;
    cout << "Nhap cac phan tu cua mang:\n";
    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }
}

// hàm in mảng
void inmang(int a[], int n) {
    for (int i = 0; i < n; i++) {
        cout << a[i] << "\t";
    }
    cout << endl;
}

// hàm sắp xếp mảng (bubble sort)
void sapxepsuibot(int a[], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (a[j] > a[j + 1]) {
                int temp = a[j];
                a[j] = a[j + 1];
                a[j + 1] = temp;
            }
        }
    }
}

int main() {
    int a[10];
    int n;

    nhapmang(a, n);

    cout << "Mang vua nhap:\n";
    inmang(a, n);

    sapxepsuibot(a, n);

    cout << "Mang sau khi sap xep:\n";
    inmang(a, n);

    return 0;
}
