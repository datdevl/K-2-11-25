#include <iostream>
using namespace std;
int main(){
    cout << "Xin chào" << endl;
    cout << "CNTT 19-07" << endl;
    return 0;
}