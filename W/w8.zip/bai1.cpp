#include <iostream>
using namespace std;

// Hàm cấp phát mảng động
int* capPhatMang(int n) {
    int* a = new int[n];
    return a;
}

int main() {
    int n;
    cout << "Nhap so phan tu: ";
    cin >> n;

    int* a = capPhatMang(n);   // gọi hàm cấp phát

    // Nhập mảng
    for (int i = 0; i < n; i++) {
        cout << "a[" << i << "] = ";
        cin >> a[i];
    }

    // Xuất mảng
    cout << "Mang vua nhap: ";
    for (int i = 0; i < n; i++) {
        cout << a[i] << " ";
    }

    // Giải phóng bộ nhớ
    delete[] a;
    return 0;
}
