#include <iostream> //tinh tong a+b
using namespace std;
int main() {
    int a=10;
    int b=11;
    int c,d,e;
    float f;
    c=a+b;
    d=a*b;
    e=a-b;
    f=(float)a/b;
    cout<<"Tích của "<<a<<" và "<<b<<" là: "<<d<<endl;
    cout<<"Tổng của "<<a<<" và "<<b<<" là: "<<c<<endl;
    cout<<"Hiệu của "<<a<<" và "<<b<<" là: "<<e<<endl;
    cout<<"Thương của "<<a<<" và "<<b<<" là: "<<f<<endl;
    cout<<
}