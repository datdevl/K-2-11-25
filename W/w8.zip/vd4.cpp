#include <iostream>
#include <string>
using namespace std;

struct NhanVien {
    string hoten;
    int tuoi;
    float giolam;
    double dongia;
    double tienluong;
};

int main() {
    int n;
    cout << "Nhap so luong nhan vien: ";
    cin >> n;

    // CẤP PHÁT ĐỘNG
    NhanVien* nv = new NhanVien[n];

    // NHẬP DỮ LIỆU
    for (int i = 0; i < n; i++) {
        cout << "\nNhap thong tin nhan vien thu " << i + 1 << endl;

        cout << "Ho ten: ";
        cin>>nv[i].hoten;

        cout << "Tuoi: ";
        cin >> nv[i].tuoi;

        cout << "Gio lam: ";
        cin >> nv[i].giolam;

        cout << "Don gia: ";
        cin >> nv[i].dongia;

        nv[i].tienluong = nv[i].giolam * nv[i].dongia;
    }

    // HIỂN THỊ DỮ LIỆU
    cout << "\n===== DANH SACH NHAN VIEN =====\n";
    for (int i = 0; i < n; i++) {
        cout << "-----------------------------\n";
        cout << "Ho ten     : " << nv[i].hoten << endl;
        cout << "Tuoi       : " << nv[i].tuoi << endl;
        cout << "Gio lam    : " << nv[i].giolam << endl;
        cout << "Don gia    : " << nv[i].dongia << endl;
        cout << "Tien luong : " << nv[i].tienluong << endl;
    }

    delete[] nv;

    return 0;
}
