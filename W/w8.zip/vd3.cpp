#include <iostream>
using namespace std;
int main(){
    int *mang;
    int n;
    cout<<"Mời nhập N: ";cin>>n;
    mang=new int[n];
    for (int i=1;i<n+1;i++){
        cout<<"Mời nhập phần tử thứ "<<i<<": "<<endl;
        cin>>*(mang+i);

        }
    for (int i=1;i<n+1;i++){
        cout<<*(mang+i)<<endl;
    }
    delete []mang;
    return 0;
}