#include <iostream>
#include <string>
#include <iomanip>
using namespace std;
// định nghĩa kiểu dữ liệu nhân viên
struct nhanvien{
	string hoten;
	int tuoi;
	float giolam;
	double dongia;
	double tienluong;
	// tienluong = giolam*dongia
};
int main(){
	nhanvien *nv;
	int n;
	// nhập số lượng nhân viên n từ bàn phím
	cout << "nhap so nhan vien " << endl;
	cin >> n;
	// cấp phát động mảng nv
	nv = new nhanvien[n];
	for (int i = 0; i < n; i++){
		cout << "nhap ten cua  nhan vien" << endl;
		cin.ignore();
		getline(cin,nv[i].hoten);
		cout << "nhap tuoi cua  nhan vien" << endl;
		cin >> nv[i].tuoi;
		cout << "nhap gio lam cua  nhan vien" << endl;
		cin >> nv[i].giolam;
		cout << "nhap don gia cua  nhan vien" << endl;
		cin >> nv[i].dongia;
		nv[i].tienluong = nv[i].giolam + nv[i].dongia;
	}
	for (int i =0; i < n; i++){
		cout <<"ho ten nhan vien thu " << i << endl;
		cout << nv[i].hoten << endl;
		cout <<"tuoi nhan vien thu " << i << endl;
		cout << nv[i].tuoi << endl;
		cout <<"so gia lam cua nhan vien thu " << i << endl;
		cout << nv[i].giolam << endl;
		cout <<"don gia nhan vien thu " << i << endl;
		cout << nv[i].dongia << endl;
		cout <<"tien luong nhan vien thu " << i << endl;
		cout << nv[i].tienluong << endl;
	}
	delete [] nv;
	return 0;
}