#include <iostream>
using namespace std;
int main(){
   cout<<"BÁNH TRÔI NƯỚC"<<endl;
	cout<<"(Hồ Xuân Hương)"<<endl;
	cout<<"Thân em vừa trắng lại vừa tròn"<<endl;
	cout<<"Bảy nổi ba chìm với nước non"<<endl;
	cout<<"Rắn nát mặc dầu tay kẻ nặn"<<endl;
	cout<<"Mà em vẫn giữ tấm lòng son"<<endl;
	return 0;
}