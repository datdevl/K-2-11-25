#include <iostream>
#include <string> //    sử dụng kiểu dữ liệu string
using namespace std;
int main(){
    int x; //khai báo biến x kiểu int
    x=1;    //gán giá trị 1 cho biến x
    float b;
    int a;
    string n;
    cout << "Nhập tên của bạn: ";
    cin>>n;
    cout<<"Nhập số bạn thích: ";;
    cin>>b;
    cout<<"Nhập điểm trung bình: ";
    cin>>b;
    cout<<"_____________________________"<<endl;
    cout<<"Xin chào "<<endl;
    cout<<"Tên của bạn là: "<<n<<endl;
    cout<<"Số bạn thích là: "<<b<<endl;
    cout<<"Điểm trung bình của bạn là: "<<b<<endl;
    return 0;
}