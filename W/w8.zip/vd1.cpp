//hiển thị thông tin về lương của nhân viên bằng struct
//tính tiền lương của họ dựa vào số giờ làm việc và lương theo giờ
//yêu cầu bài ra: nhập và hiển thị tt về luwogn của nhân viền
// đầu ra: sanh sách nhân viên có thông tin về lương = số giờ * đơn giá
//B1: KHAI BÁO KIỂU STRUCT 
#include <iostream>
#include <string>
using namespace std;
struct nhanvien{
    string hoten;
    int tuoi;
    float giolam;
    double dongia;
    double tienluong;//=giolam*dongia
};
int main(){
    nhanvien nv[100];
    int n;
    cout<<"Nhập số lượng nhân viên: ";cin>>n;
    for (int i=1;i<n+1;i++){
        cout<<"Nhập tên nhân viên thứ "<<i<<": ";cin>>nv[i].hoten;//getline cho phép nhập được dấu cách
        cout<<"Nhập tuổi nhân viên thứ "<<i<<": ";cin>>nv[i].tuoi;
        cout<<"Nhập giờ làm của nhân viên thứ "<<i<<": ";cin>>nv[i].giolam;
        cout<<"Nhập đơn giá của nhân viên thứ "<<i<<": ";cin>>nv[i].dongia;
        cout<<"Tiền lương của nhân viên thứ "<<i<<": ";cout<<(float)nv[i].giolam*nv[i].dongia<<endl;
    }
    for (int i=1;i<n+1;i++){
        cout<<"+++++++++++++++++++"<<endl;
        cout<<"THÔNG TIN NHÂN VIÊN"<<endl;
        cout<<nv[i].hoten<<endl;
        cout<<nv[i].tuoi<<endl;
        cout<<nv[i].giolam<<endl;
        cout<<nv[i].dongia<<endl;
        cout<<(float)nv[i].giolam*nv[i].dongia<<endl;
        cout<<"+++++++++++++++++++"<<endl;
    }
}