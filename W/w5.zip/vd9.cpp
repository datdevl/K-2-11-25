//hàm tên không dùng return
#include <iostream>
using namespace std;
void timesTen(){
    int num;
    cin>>num;
    for (int i=1;i<11;i++){
        cout<<num<<endl;
    }
}
int main(){
timesTen();
}
