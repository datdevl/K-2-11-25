// Ví dụ 1 Viết chương trình có định nghĩa hàm công 2 số a và b là số nguyên trả ra
// giá trị tổng có kiểu dữ liệu là số nguyên
	// đầu vào số nguyên a và b
	// yêu cầu đầu ra là hàm tính tổng a và b  kiểu dữ liệu trả ra là số nguyên
	// gọi hàm trong hàm main
	// bước 1: khai báo biến 
	// bước 2 viết hàm
	// bước 3 gọi hàm

#include <iostream>
using namespace std;
int cong(int a, int b){ // định nghĩa hàm công trước hàm main()
	int c;
	c = a + b;
	return c;
}
int main(){

	int so1, so2, kq;
	cout << "nhap so 1" << endl;
	cin >> so1;
	cout << "Nhap so 2" << endl;
	cin >> so2;
	kq = cong(so1,so2);
	cout << "ket qua phep cong la " << kq << endl;
	return 0;
}