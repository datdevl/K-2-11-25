//hàm nguyên mẫu
#include <iostream>
using namespace std;
int timesTen(int number){
    for (int i=1;i<11;i++){
        cout<<number<<endl;
    }
    return number;
}

int main(){
    int num;
    cin>>num;
    cout<<timesTen(num);

}