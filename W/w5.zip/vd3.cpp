#include<iostream>
#include <fstream>
#include <string>
using namespace std;
int main(){
	string chuoi;
	fstream fileinput;
	fileinput.open("CNTT1907.txt");
	while (fileinput.eof()==false){
			getline(fileinput, chuoi);
			cout << chuoi << endl;

	}
	fileinput.close();
	return	 0;
}