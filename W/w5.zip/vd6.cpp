#include <iostream>
using namespace std;

void inchu() {
    cout << "Tôi Yêu Đại Học Đại Nam";
}

int main() {
    inchu();
    return 0;
}
