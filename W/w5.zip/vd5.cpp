#include<iostream>
#include <fstream>
#include <string>
using namespace std;
int main(){
	string chuoi;
	ofstream fileout;
// doc vao file 
	fileout.open("1907.txt");
	cin >> chuoi;
	fileout << chuoi;
	fileout.close();
	return 0;
}