#include <iostream>
#include <fstream>
using namespace std;
int main(){
    string chuoi1,chuoi2, chuoi3,chuoi4,chuoi5;
    fstream fileinput;
    fileinput.open("CNTT.txt");
    fileinput>>chuoi1;
    fileinput>>chuoi2;
    fileinput>>chuoi3;
    fileinput>>chuoi4;
    fileinput>>chuoi5;
    cout<<chuoi1<<endl;
    cout<<chuoi2<<endl;
    cout<<chuoi3<<endl;
    cout<<chuoi4<<endl;
    cout<<chuoi5<<endl;
}