#include <iostream>
using namespace std;
void timesten(int number){
    for (int i=0;i<10;i++){
        cout<<number<<endl;
    }
}
int main(){
    timesten(10);
    return 0;
}
