#include <iostream>
using namespace std;
int tong(int a, int b){
    int c;
    c=a+b;
    return c;
}    
int main(){
    // đầu vào là 2 số nguyên A;B 
    // đầu ra là hàm tính tổng A;B kiểu dữ liệu INT
    //gọi hàm tronng hàm main
    int A,B;
    cout<<"A=";cin>>A;
    cout<<"B=";cin>>B;
    cout<<tong(A,B);
}