#include<iostream>
#include <fstream>
#include <string>
using namespace std;
int main(){
	string chuoi1,chuoi2,chuoi3;
	fstream fileinput;
	fileinput.open("CNTT.txt");
	getline(fileinput,chuoi1);
	getline(fileinput, chuoi2);
	cout << chuoi1 << endl;
	cout << chuoi2 << endl;
	fileinput.close();
	return 0;
}