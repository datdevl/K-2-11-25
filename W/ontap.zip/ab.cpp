#include <iostream>
#include <math.h>
using namespace std;
int main(){
    float a,b,c;
    cout<<"A=";
    cin>>a;
    cout<<"B=";
    cin>>b;
    cout<<"C=";
    cin>>c;
    cout<<a<<"+"<<b<<"="<<a+b<<endl;
    if ((a+b>c) && (a+c>b) && (b+c>a)){
        cout<<"Chu vi tam giác: "<<a+b+c<<endl;
        cout<<"Nửa Chu vi tam giác: "<<(a+b+c)/2<<endl;
        cout<<"Diện tích tam giác: "<<sqrt(((a+b+c)/2)*(((a+b+c)/2)-a)*(((a+b+c))/2-b)*(((a+b+c)/2)-c));
    }
    else{
        cout<<"ERROR";
    }
    return 0;
}