#include <iostream>
using namespace std;
int main(){
    float a,b,c;
    cin>>a>>b>>c;
    if ((a+b>c) && (a+c>b) && (b+c>a) && (a>0) && (b>0) && (c>0)){
        cout<<" Là 3 cạnh của tam giác";
    }
    else {
        cout<<" Không là 3 cạnh của tam giác";
    }
}