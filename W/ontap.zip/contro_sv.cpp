#include <iostream>
#include <string>
using namespace std;
struct sinhvien{
    int masv;
    string hoten;
    float diem;
};
int main(){
    // sinhvien a[10]; dùng thông thường
    //khai báo con trỏ và cấp phát động
    sinhvien *a;
     //
    int n;
    a = new sinhvien[n+1];
    float s=0;
    cout<<"Nhập số lượng sinh viên: ";
    cin>>n;
    a = new sinhvien[n+1];
    for (int i=1;i<=n+1;i++){ // nhập dữ liệu
        cout<<"MSV thứ "<<i<<": ";
        cin>>a[i].masv;
        cin.ignore();
        cout<<"Họ tên SV thứ "<<i<<": ";
        
        getline(cin, a[i].hoten);
        cout<<"Điểm của SV thứ "<<i<<": ";
        cin>>a[i].diem;
    }
    cout<<"========="<<endl;
    for (int i=1;i<=n+1;i++){
        cout<<a[i].masv<<endl;
        cout<<a[i].hoten<<endl;
        cout<<a[i].diem<<endl;
    }
    cout<<"======"<<endl;
    for (int i=1;i<=n;i++){
        s=s+a[i].diem;
    }
    cout<<"Tổng Điểm SV: "<<s;
    delete [] a;
    return 0;
}
