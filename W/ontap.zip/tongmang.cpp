#include <iostream>
using namespace std;
int main(){
    int a[100];
    int s=0;
    for (int j=0;j<10;j++){
        cout<<"a=["<<j<<"]=";
        cin>>a[j];
    }
    for (int i=0;i<10;i++){
        cout<<"a["<<i<<"]="<<a[i]<<endl;
        s=s+a[i];
    }
    cout<<"Tổng mảng: "<<s;

    return 0;

}