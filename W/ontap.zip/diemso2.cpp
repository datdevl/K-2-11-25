#include <iostream>
using namespace std;
int main(){
    float n;
    cin>>n;
    if (n<5){
        cout<<"hsy";
    }
    else if(n<7){
        cout<<"hstb";
    }
    else if (n<9){
        cout<<"hsk";
    }
    else if (n<10){
        cout<<"hsg";
    } 
    
}