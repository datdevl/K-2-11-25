#include <iostream>
#include <string>
using namespace std;
struct ThanhPho{
    string TenTP;
    long DanSo;
};

int main(){
    ThanhPho tp[10];
    int n;
    long s=0,tb=0;
    cout<<"SL TP: "<<endl;
    cin>>n;
    for (int i=0;i<n;i++){
        cout<<"Tên TP thứ "<<i<<endl;
        cin>>tp[i].TenTP;
        cout<<"Dân Số: "<<i<<endl;
        cin>>tp[i].DanSo;

    }
    for (int i=0;i<n;i++){
        cout<<tp[i].TenTP<<endl;
        cout<<tp[i].DanSo<<endl;
    }
    for (int i=0;i<n;i++){
        s=s+tp[i].DanSo;
    }
    tb=s/n;
    cout<<"Trung Bình Các TP: "<<tb;
    return 0;
}
