#include <iostream>
#include <string>
#include <iomanip>
using namespace std;
int main(){
    string str;
    cin>>str;
    getline(cin,str);
    cout<<str;
    return 0;
}