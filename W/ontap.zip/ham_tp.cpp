#include <iostream>
#include <string>
using namespace std;

struct ThanhPho{
    string TenTP;
    long DanSo;
};

void nhap(ThanhPho a[], int n){
    cin.ignore(); // xóa Enter ban đầu
    for (int i = 0; i < n; i++){
        cout << "Ten TP thu " << i+1 << ": ";
        getline(cin, a[i].TenTP);

        cout << "Dan so: ";
        cin >> a[i].DanSo;
        cin.ignore(); // chuẩn cho vòng sau
    }
}
void in(ThanhPho a[], int n){
    for (int i = 0; i < n; i++){
    cout << a[i].TenTP << endl;
    cout << a[i].DanSo << endl;
    }
}
float tb(ThanhPho a[], int n){
    float s = 0;
    float tb;
    for (int i = 0; i < n; i++){
    s += a[i].DanSo;
    }
    tb = s / n;
    return tb;
}
int main(){
    ThanhPho tp[10];
    int n;

    cout << "SL TP: ";
    cin >> n;

    nhap(tp, n); // gọi đúng
    cout << "=========" << endl;
    in(tp,n);
    float kq = tb(tp, n);
    cout << "Trung binh cac TP: " << kq;

    return 0;
}