#include <iostream>
using namespace std;
int main(){
    int calo;
    for (int i=5;i<=30;i=i+5){
        cout<<"calo cân cho "<<i<<" phút là: "<<i*15<<endl;
    }
}