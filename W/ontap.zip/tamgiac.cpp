#include <iostream>
#include <cmath> // Dùng cmath thay cho math.h
using namespace std;

int main(){
    float a, b, c;
    cout << "A="; cin >> a;
    cout << "B="; cin >> b;
    cout << "C="; cin >> c;

    if ((a + b > c) && (a + c > b) && (b + c > a)) {
        float p = (a + b + c) / 2; // Đặt biến p cho gọn
        cout << "Chu vi tam giac: " << a + b + c << endl;
        cout << "Nua Chu vi tam giac: " << p << endl;
        cout << "Dien tich tam giac: " << sqrt(p * (p - a) * (p - b) * (p - c)) << endl;
    } else {
        cout << "ERROR: Khong phai ba canh tam giac!";
    }
    return 0;
}
