#include <iostream>
using namespace std;
int main(){
    float n;
    cin>>n;
    if (n>=9 && n<=10){
        cout<<"hsg";
    }
    else if (n>=7 && n<9){
        cout<<"hsk";
    }
    else if (n>=5 && n<7){
        cout<<"hstb";
    }
    else if (n<=5 && n>=0){
        cout<<"hsy";
    }
    else{
        cout<<"sai diem";
    }
    return 0;
}