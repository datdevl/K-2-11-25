#include <iostream>
using namespace std;
int main(){
    int a,b;
    a=0;
    while (a<=10){
        cout<<a<<endl;
        a=a+2;
    }  
    return 0;
}