#include <iostream>
using namespace std;
int main(){
    int n=5;
    while (n<=100){
        cout<<n<<endl;
        n=n+5;
    }
    return 0;
}