#include <iostream>
using namespace std;
int main(){
    int a;
    cin>>a;
    while (a>1){
        cout<<"Anh iu Em";
    }
}