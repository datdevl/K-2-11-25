#include <iostream>
#include <string>
using namespace std;

struct ThanhPho{
    string TenTP;
    long DanSo;
};

// Nhập dữ liệu
void nhap(ThanhPho a[], int n){
    cin.ignore();
    for (int i = 0; i < n; i++){
        cout << "Ten TP thu " << i+1 << ": ";
        getline(cin, a[i].TenTP);

        cout << "Dan so: ";
        cin >> a[i].DanSo;
        cin.ignore();
    }
}

// Xuất dữ liệu
void xuat(ThanhPho a[], int n){
    cout << "=========" << endl;
    for (int i = 0; i < n; i++){
        cout << a[i].TenTP << " - " << a[i].DanSo << endl;
    }
}

// Tính tổng dân số
void tong(ThanhPho a[], int n){
    long s = 0;
    for (int i = 0; i < n; i++){
        s += a[i].DanSo;
    }
    cout << "Tong dan so: " << s << endl;
}

// Tính trung bình
void trungbinh(ThanhPho a[], int n){
    long s = 0;
    for (int i = 0; i < n; i++){
        s += a[i].DanSo;
    }
    float tb = (float)s / n;
    cout << "Trung binh dan so: " << tb << endl;
}

int main(){
    ThanhPho tp[100];
    int n;

    cout << "Nhap so luong TP: ";
    cin >> n;

    nhap(tp, n);
    xuat(tp, n);
    tong(tp, n);
    trungbinh(tp, n);

    return 0;
}