#include <iostream>
using namespace std;
int main(){
    cout<<2*80<<endl;
    for (int i=1; i<=20;i=i+5){
        cout<<i*80<<endl;
    }
    return 0;
}