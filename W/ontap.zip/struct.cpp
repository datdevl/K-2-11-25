#include <iostream>
#include <string>
using namespace std;
struct sinhvien{
    int masv;
    string hoten;
    float diem;
};
int main(){
    sinhvien a;
    cout<<"MSV:";
    cin>>a.masv;
    cout<<"Họ Tên:";
    cin.ignore(); // xóa kí tự Enter 
    getline(cin,a.hoten); //cin không lấy được dấu cách
    cout<<"Điểm:";
    cin>>a.diem;
    cout<<"========"<<endl;
    cout<<a.masv<<endl;
    cout<<a.hoten<<endl;
    cout<<a.diem<<endl;
    return 0;
}