#include <iostream>
#include <string>
#include <iomanip>
using namespace std;
int main(){
    string str;
    cin>>str;
    getline(cin,str);
    cout<<setw(8)<<str;
    return 0;
}