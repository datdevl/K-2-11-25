#include <iostream>
using namespace std;
int main(){
    int vt,tong=0;
    int gio;
    while (gio<=10){
        cout<<gio<<endl;
        tong=tong+30;
        gio ++;
    }
    return 0;
}