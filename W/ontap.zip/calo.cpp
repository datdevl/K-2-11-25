#include <iostream>
using namespace std;
int main(){
    int calo;
    int i=5;
    while (i<=30){
        cout<<"calo cân cho "<<i<<" phút là: "<<i*15<<endl;
        i=i+5;
    }
}