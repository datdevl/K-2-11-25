#include <iostream>
using namespace std;
int main(){
    int gt=1;
    for (int i=1;i<=6;i++){
        gt=gt*i;
        cout<<i<<"!="<<gt<<endl;
    }
    return 0;
}