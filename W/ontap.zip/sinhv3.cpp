#include <iostream>
#include <string>
#include <iomanip>
using namespace std;
struct Sinhvien{
    string MSV;
    string HT;
    int math;
    int code;


};
int main(){
    Sinhvien sv[100];
    int n;
    float s=0;
    cin>>n;
    for (int i=0;i<n;i++){
        cin>>sv[i].MSV;
        cin>>sv[i].HT;
        cin>>sv[i].math;
        cin>>sv[i].code;
    }
    float maxDTB=-1;
    int tmp=0;
    for (int i=0;i<n;i++){
        float tb=(sv[i].math+sv[i].code)/2;
        if (tb>maxDTB){
            maxDTB=tb;
            tmp=i;
        }
    }
    cout<<sv[tmp].MSV<<" "<<sv[tmp].HT<<" "<<fixed<<setprecision(2)<<maxDTB;

    
    return 0;
}