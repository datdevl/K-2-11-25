#include <iostream>
using namespace std;
int main(){
    float n;
    cin>>n;
    if (n<20){
        cout<<"cham";
    }else if (n<=60){
        cout<<"binh thuong";
    }else if (n>60){
        cout<<"cao";
    }
}