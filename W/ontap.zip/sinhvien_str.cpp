#include <iostream>
#include <string>
using namespace std;
struct sinhvien{
    int masv;
    string hoten;
    int diem;
};
int main(){
    sinhvien a[10];
    int n;
    float s=0;
    cout<<"Nhập số lượng sinh viên: ";
    cin>>n;
    for (int i=1;i<=n;i++){ // nhập dữ liệu
        cout<<"MSV thứ "<<i<<": ";
        cin>>a[i].masv;
        cout<<"Họ tên SV thứ "<<i<<": ";
        cin.ignore();
        getline(cin,a[i].hoten);
        cout<<"Điểm của SV thứ "<<i<<": ";
        cin>>a[i].diem;
    }
    cout<<"========="<<endl;
    for (int i=1;i<=n;i++){
        cout<<a[i].masv<<endl;
        cout<<a[i].hoten<<endl;
        cout<<a[i].diem<<endl;
    }
    cout<<"======"<<endl;
    for (int i=1;i<=n;i++){
        s=s+a[i].diem;
    }
    cout<<"Tổng Điểm SV: "<<s;
    return 0;
}
